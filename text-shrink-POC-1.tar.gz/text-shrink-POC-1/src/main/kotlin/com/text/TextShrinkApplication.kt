package com.text

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class TextShrinkApplication

fun main(args: Array<String>) {
    runApplication<TextShrinkApplication>(*args)
}
