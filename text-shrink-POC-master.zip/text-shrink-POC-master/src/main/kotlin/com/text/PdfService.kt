package com.text

import com.gargoylesoftware.htmlunit.CollectingAlertHandler
import com.gargoylesoftware.htmlunit.StringWebResponse
import com.gargoylesoftware.htmlunit.WebClient
import com.gargoylesoftware.htmlunit.html.XHtmlPage
import com.gargoylesoftware.htmlunit.javascript.host.Element
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument
import com.openhtmltopdf.pdfboxout.PdfRendererBuilder
import com.openhtmltopdf.util.XRLog
import org.w3c.tidy.Tidy
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.URL
import java.nio.file.FileSystems

val html =
    "<html>" +
        "<head>" +
        "<style>" +
        ".current-title-box {" +
        "   width: 120px;" +
        "   font-size: 40px;" +
        "   border: 1px solid black;" +
        "}" +
        ".current-title {" +
        "   height: 60px;" +
        "}" +
        ".future-title {" +
        "   margin-top: 200px;" +
        "   width: 120px;" +
        "   height: 60px;" +
        "   font-size: 40px;" +
        "   border: 1px solid black;" +
        "}" +
        "</style>" +
        "</head>" +
        "<body>" +
        "<div class=\"current-title-box\">" +
        "<span class=\"current-title\">" +
        "This is how it currently works with 2.44.0. The text should shrink down to fit into the box." +
        "</span>" +
        "</div>" +
        "<div class=\"future-title\">" +
        "This is my ideal use case in the future. The text should shrink down to fit into the box." +
        "</div>" +
        "</body>" +
        "</html>"

val javascript =
    "var currentTitleBox = document.querySelector(\".current-title-box\");" +
        "var currentTitle = document.querySelector(\".current-title\");" +
        "var currentTitleFontSize = window.getComputedStyle(currentTitle)[\"fontSize\"].split(\"px\")[0];" +
        "var currentTitleHeightGoal = window.getComputedStyle(currentTitle)[\"height\"].split(\"px\")[0];" +

        "alert('initial currentTitleBox offsetHeight inside javascript: ' + currentTitleBox.offsetHeight);" +
        "alert('initial currentTitleBox scrollHeight inside javascript: ' + currentTitleBox.scrollHeight);" +

        "while (currentTitleBox.offsetHeight > currentTitleHeightGoal) {" +
        "    currentTitleFontSize -= 1;" +
        "    currentTitleBox.style.fontSize = currentTitleFontSize;" +
        "}" +

        "var futureTitle = document.querySelector(\".future-title\");" +
        "var futureTitleFontSize = window.getComputedStyle(futureTitle)[\"fontSize\"].split(\"px\")[0];" +
        "var futureTitleHeightGoal = window.getComputedStyle(futureTitle)[\"height\"].split(\"px\")[0];" +

        "alert('initial futureTitle offsetHeight inside javascript: ' + futureTitle.offsetHeight);" +
        "alert('initial futureTitle scrollHeight inside javascript: ' + futureTitle.scrollHeight);" +

        "while (futureTitle.scrollHeight > futureTitleHeightGoal) {" +
        "    futureTitleFontSize -= 1;" +
        "    futureTitle.style.fontSize = futureTitleFontSize;" +
        "}"

private fun processWithHtmlUnit(): String {
    val client = WebClient()
    val window = client.getCurrentWindow()
    client.getOptions().setThrowExceptionOnScriptError(false)
    // set up alert handler
    val alertHandler = CollectingAlertHandler()
    client.setAlertHandler(alertHandler)

    // start up the page and get its html
    val response = StringWebResponse(convertToXhtml(html), URL("file:"))
    val page = XHtmlPage(response, window)
    window.setEnclosedPage(page)
    client.getPageCreator().getHtmlParser().parse(response, page, true)

    val scriptableObject = page.getScriptableObject<HTMLDocument>().body
    val currentTitleElement = scriptableObject.getElementsByClassName("current-title")[0] as Element
    val futureTitleElement = scriptableObject.getElementsByClassName("future-title")[0] as Element

    val currentStyles = scriptableObject.getWindow().getComputedStyle(currentTitleElement, null)
    val futureStyles = scriptableObject.getWindow().getComputedStyle(futureTitleElement, null)

    println("initial current calculatedHeight before javascript: " + currentStyles.getCalculatedHeight(false, false))
    println("initial current scrollHeight before javascript: " + currentTitleElement.getScrollHeight())
    println("initial future calculatedHeight before javascript: " + futureStyles.getCalculatedHeight(false, false))
    println("initial future scrollHeight before javascript: " + futureTitleElement.getScrollHeight())

    page.executeJavaScript(javascript)

    // log alerts from javascript
    alertHandler.getCollectedAlerts().forEach { alert -> println(alert) }

    // get the new html
    val htmlDocument = page.getScriptableObject<HTMLDocument>()
    val newHtml = htmlDocument.getDocumentElement().getInnerHTML()
    client.close()

    return newHtml
}

fun renderPdf(): ByteArrayInputStream {
    XRLog.setLoggingEnabled(false)

    //render pdf
    val openHtmlBuilder = PdfRendererBuilder()
    openHtmlBuilder.useFastMode()
    // set HTML content
    openHtmlBuilder.withHtmlContent(
        convertToXhtml(processWithHtmlUnit()),
        FileSystems
            .getDefault()
            .toString()
    )

    // set output stream
    val outputArray = ByteArrayOutputStream()
    openHtmlBuilder.toStream(outputArray)
    // create document
    openHtmlBuilder.run()

    return ByteArrayInputStream(outputArray.toByteArray())
}

private fun convertToXhtml(html: String): String {
    val tidy = Tidy()
    tidy.setInputEncoding("UTF-8")
    tidy.setOutputEncoding("UTF-8")
    tidy.setXHTML(true)
    tidy.setShowWarnings(false)
    tidy.setQuiet(true)
    val inputStream = ByteArrayInputStream(html.toByteArray())
    val outputStream = ByteArrayOutputStream()
    tidy.parseDOM(inputStream, outputStream)
    return outputStream.toString("UTF-8")
}
