package com.text

import kotlinx.coroutines.runBlocking
import org.springframework.core.io.InputStreamResource
import org.springframework.core.io.Resource
import org.springframework.http.HttpHeaders
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/")
class PreviewController {
    @GetMapping("", produces = [MediaType.APPLICATION_JSON_VALUE])
    fun generatePreview(): ResponseEntity<Resource> {
        val headers = HttpHeaders()
        headers.add("Content-Disposition", "inline; filename=template.pdf")
        val output = runBlocking { renderPdf() }
        return ResponseEntity
            .ok()
            .headers(headers)
            .contentType(MediaType.APPLICATION_PDF)
            .body(InputStreamResource(output))
    }
}