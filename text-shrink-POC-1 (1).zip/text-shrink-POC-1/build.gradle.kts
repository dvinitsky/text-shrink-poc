val pdfBoxVersion: String by project
val swaggerVersion: String by project
val kotlinLoggingVersion: String by project
val retrofitVersion: String by project
val htmlUnitVersion: String by project
val jtidyVersion: String by project
val thymeleafVersion: String by project
val openHtmlVersion: String by project
val j2HtmlVersion: String by project

buildscript {
    val springBootVersion: String by project
    repositories {
        jcenter()
    }
    dependencies {
        classpath("org.springframework.boot:spring-boot-gradle-plugin:$springBootVersion")
    }
}

plugins {
    application
    id("org.springframework.boot") version "2.3.0.RELEASE"
    id("io.spring.dependency-management") version "1.0.9.RELEASE"
    kotlin("jvm") version "1.3.72"
    kotlin("plugin.spring") version "1.3.72"
}

group = "com.text"
version = "0.0.1"

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

repositories {
    mavenCentral()
    jcenter()
    maven(url = "http://dl.bintray.com/kotlin/kotlinx")
    maven(url = "https://repo.spring.io/milestone")
}

application {
    mainClassName = "com.text.TextShrinkApplicationKt"
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("org.springframework.boot:spring-boot-starter-web")

    implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.11.0")
    implementation("com.fasterxml.jackson.module:jackson-module-scala_2.11:2.11.0")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.11.0")

    implementation("org.jetbrains.kotlin:kotlin-reflect")
    implementation("org.jetbrains.kotlin:kotlin-stdlib-jdk8")

    implementation("org.apache.pdfbox:pdfbox:$pdfBoxVersion")
    implementation("org.apache.commons:commons-lang3:3.9")

    implementation("io.springfox:springfox-swagger2:$swaggerVersion")
    implementation("io.springfox:springfox-swagger-ui:$swaggerVersion")

    implementation("io.github.microutils:kotlin-logging:$kotlinLoggingVersion")
    implementation("net.logstash.logback:logstash-logback-encoder:6.1")

    implementation("com.squareup.retrofit2:retrofit:$retrofitVersion")
    implementation("com.squareup.retrofit2:converter-jackson:$retrofitVersion")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.3.7")

    // required for templates
    implementation("org.thymeleaf:thymeleaf:$thymeleafVersion")
    implementation("net.sourceforge.htmlunit:htmlunit:$htmlUnitVersion")
    implementation("com.openhtmltopdf:openhtmltopdf-core:$openHtmlVersion")
    implementation("com.openhtmltopdf:openhtmltopdf-pdfbox:$openHtmlVersion")
    implementation("net.sf.jtidy:jtidy:$jtidyVersion")
    implementation("com.j2html:j2html:$j2HtmlVersion")

    testImplementation("org.springframework.boot:spring-boot-starter-test") {
        exclude(group = "org.junit.vintage", module = "junit-vintage-engine")
    }
    testImplementation("io.mockk:mockk:1.10.0")
}

tasks.getByName<Jar>("jar") {
    enabled = true
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
    kotlinOptions {
        freeCompilerArgs = listOf("-Xjsr305=strict")
        jvmTarget = "11"
    }
}

configurations.all {
    exclude(module = "spring-boot-starter-logging")
}